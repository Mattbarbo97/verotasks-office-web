var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var officeSignal_exports = {};
__export(officeSignal_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(officeSignal_exports);
async function handler(event) {
  try {
    if (event.httpMethod !== "POST") {
      return { statusCode: 405, body: JSON.stringify({ ok: false, error: "method_not_allowed" }) };
    }
    const API_BASE_URL = process.env.API_BASE_URL;
    const OFFICE_API_SECRET = process.env.OFFICE_API_SECRET;
    if (!API_BASE_URL || !OFFICE_API_SECRET) {
      return { statusCode: 500, body: JSON.stringify({ ok: false, error: "missing_env" }) };
    }
    const body = event.body ? JSON.parse(event.body) : {};
    const resp = await fetch(`${API_BASE_URL}/office/signal`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Office-Secret": OFFICE_API_SECRET
      },
      body: JSON.stringify(body)
    });
    const json = await resp.json().catch(() => null);
    return {
      statusCode: resp.status,
      body: JSON.stringify(json || { ok: false, error: "bad_response" })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ ok: false, error: "server_error" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
